=== Simple Auto Tag===
Contributors: djjmz
Requires at least: 3.6
Tested up to: 4.1 
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WYDR4ADESD2KU&lc=LT&item_name=Donate&no_note=1&no_shipping=1&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: auto, tag, simple, fast, free, post, page

== Changelog ==

= 1.1 =
* Small code update
= 1.0.3 =
* Add bug fix
= 1.0.2 =
* Add new function
= 1.0.1 =
* Small bug fix
= 1.0.0 =
* First Release

== Description ==

Simple way to create auto tags from post/page title.
 

== Installation ==

1.  Upload simple-auto-tag folder to plugins folder.

2.  Chmod words.txt file for 777 rights.

3.  Go to Plugins menu and active.



== Frequently Asked Questions ==

= Can I use this plugin for Free? =

Yes absolutely.





