#!/bin/bash
sed -i 's/\r//g' $0
limit=1; # 10 site / request  --proxy "http://bloodsaker97.gmail.com:ei6ybn@gate2.proxyfuel.com:2000" 
rev(){
r='\e[31m'
g='\e[32m'
d='\e[39m'
    for i in {1..100} #114 iki total page ne kabeh ra mesti 114 totale kabeh domain tiap harine
    do
    curl=$(curl -s -A "Mozilla/5.0" --url "https://www.cubdomain.com/domains-registered-by-date/$url/${i}")
    if [[ $curl == *"col-md-4"* ]];then
        grep=$(echo ${curl} | grep -Po '(?<=https://www.cubdomain.com/site/).*?(?=">)')
        total=$(echo "$grep" | wc -l)
		echo -e "${url} : TOTAL $g${total}$d : PAGE $r${i}$d"
        echo "${grep}">>cubdomain.txt
    else
        break
    fi
    done

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        rev ${url} 
    done
        wait