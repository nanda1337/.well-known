#!/bin/bash
sed -i 's/\r//g' $0
limit=1; # 10 site / request  --proxy "http://bloodsaker97.gmail.com:ei6ybn@gate2.proxyfuel.com:2000" 
rev(){
r='\e[31m'
g='\e[32m'
d='\e[39m'
    for i in {1..180} #114 iki total page ne kabeh ra mesti 114 totale kabeh domain tiap harine
    do
    curl=$(curl -s --connect-timeout 15 --url "https://www.uidomains.com/browse-daily-domains-difference/${i}/${url}")
    if [[ $curl == *"domains-list"* ]];then
        grep=$(echo ${curl} | grep -Po '(?<=<li>).*?(?=</li>)')
        total=$(echo "$grep" | wc -l)
		echo -e "${url} : PAGE $r${i}$d TOTAL : $g${total}$d"
        echo "${grep}">>uidomains.txt
    else
        echo -e "${url} => NO"
    fi
    done

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        rev ${url} 
    done
        wait