#!/bin/bash
sed -i 's/\r//g' $0
limit=10; # 10 site / request
rev(){
r='\e[31m'
g='\e[32m'
d='\e[39m'
    curl=$(curl -s --connect-timeout 15 --url "https://sonar.omnisint.io/reverse/${url}")
    if [[ $curl == *"no results found"* ]];then
		echo -e "$r#$d ${url} => $r${curl}$d"
    elif [[ $curl == *"invalid CIDR address"* ]];then
        echo -e "$r#$d ${url} => $r${curl}$d"
    else
        grep=$(echo ${curl} | grep -Po '([a-z0-9][a-z0-9\-]{0,61}[a-z0-9]\.)+[a-z0-9][a-z0-9\-]*[a-z0-9]')
        total=$(echo "$grep" | wc -l)
        echo -e "$g#$d ${url} => TOTAL : $g$total$d"
        echo "${grep}">>HASIL.txt
    fi

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        rev ${url} 
    done
        wait