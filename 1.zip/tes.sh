#!/bin/bash
sed -i 's/\r//g' $0
limit=10; # 10 site / request
rev(){
red='\e[101m'
green='\e[102m'
    curl=$(curl -s --proxy "http://bloodsaker97.gmail.com:ei6ybn@gate2.proxyfuel.com:2000" --connect-timeout 15 --url "https://networksdb.io/domains-on-ip/${url}")
    if [[ $curl == *"<p>We found <b>"* ]];then
        grep=$(echo ${curl} | grep -Po '<pre class="threecols">\K.*?(?=</pre>)')
        hasil=$(echo ${grep} | tr " " "\n")
		echo -e "${url} => OK"
        echo "${hasil}">>networksdb.txt
    else
        echo -e "${url} => NO"
    fi

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        rev ${url} 
    done
        wait