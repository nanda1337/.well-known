#   Simple Python Scanner For Search Reg3x
#   Panataran
import requests
import sys
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

listSite = sys.argv[1]
op = [i.strip() for i in open(listSite, "r").readlines()]

headers = {"User-Agent": "Apache/2.4.34 (Ubuntu) OpenSSL/1.1.1 (internal dummy connection)",
		  "Accept": "*/*",
		  "Accept-Language": "en-US,en;q=0.5",
		  "Accept-Encoding": "gzip, deflate",
		  "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
		  "X-Requested-With": "XMLHttpRequest",
		  "Connection": "close"}

def check(site):
  try:
    r = requests.get(site + "/wp-content/vd454/mm/mmd/index.php", verify=False, headers=headers, timeout=10)
    ff = open("Black_Shadow.txt", "a+")
    if '<title>Negat1ve Shell</title>' in r.content:
      print(site + "/ -> Vuln")
      ff.write(site + "/wp-content/vd454/mm/mmd/index.php\n")
    else:
            print(site + " -> no")
  except:
    print(site + " -> CMS Error")
    
tod = Pool(1)
tod.map(check, op)
tod.close()
tod.join()