#!/bin/bash
sed -i 's/\r//g' $0
limit=1; # 10 site / request  --proxy "http://bloodsaker97.gmail.com:ei6ybn@gate2.proxyfuel.com:2000" 
rev(){
r='\e[31m'
g='\e[32m'
d='\e[39m'
    for i in {1..120} #114 iki total page ne kabeh ra mesti 114 totale kabeh domain tiap harine
    do
    curl=$(curl -s --connect-timeout 15 --url "https://websitebiography.com/new_domain_registrations/${url}/${i}")
    if [[ $curl == *"Total Registered Domains"* ]];then
        grep=$(echo ${curl} | grep -Po '(?<=flexible_dv_30_50).*?(?= </a>)')
        grep1=$(echo ${grep} | grep -Po '([a-z0-9][a-z0-9\-]{0,61}[a-z0-9]\.)+[a-z0-9][a-z0-9\-]*[a-z0-9]')
        total=$(echo "$grep1" | wc -l)
		echo -e "${url} : PAGE $r${i}$d TOTAL : $g${total}$d"
        echo "${grep1}">>registered.txt
    else
        echo -e "${url} => NO"
    fi
    done

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        rev ${url} 
    done
        wait