<?php

$host = '162.241.219.197';
$dbuser = 'gloryog2_nk';
$dbpass = 'gloryog2_nk';
$dbname = 'gloryog2_nk';


try {
    $db = new PDO('mysql:host='.$host.';dbname='.$dbname.'', "$dbuser", "$dbpass");
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
